package com.susanta;

import org.junit.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Simple Add + TopN Test
     */
    @Test
    public void simpleTradeBook()
    {
        Set<String> exchanges = new HashSet<>();
        exchanges.add("NYSE");
        ConsolidatedOrderBook consolidatedOrderBook = new ConsolidatedOrderBook(exchanges);
        consolidatedOrderBook.addOrder(new Order(123456, 1,
                "MSFT", 10, true, 50.56, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 2,
                "MSFT", 6, true, 50.53, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 3,
                "MSFT", 10, true, 50.23, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 4,
                "MSFT", 10, true, 50.80, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 5,
                "MSFT", 10, true, 50.76, "NYSE"));

        consolidatedOrderBook.addOrder(new Order(123456, 1,
                "MSFT", 10, false, 51.56, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 2,
                "MSFT", 6, false, 51.53, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 3,
                "MSFT", 10, false, 51.23, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 4,
                "MSFT", 10, false, 51.80, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 5,
                "MSFT", 10, false, 51.76, "NYSE"));

        HashMap<Integer, OrderBook.TopNLevels> topNLevels = consolidatedOrderBook.getTopNLevels(5);
        OrderBook.TopNLevels level0 = topNLevels.get(0);
        assertNotNull(level0);
        assertTrue(50.8 == level0.getBidPrice());
        assertEquals(10, level0.getBidSize());
        System.out.println(topNLevels);
    }

    /**
     * Add & TopN Test
     */
    @Test
    public void consolidationTest()
    {
        Set<String> exchanges = new HashSet<>();
        exchanges.add("NYSE");
        exchanges.add("BSE");

        ConsolidatedOrderBook consolidatedOrderBook = new ConsolidatedOrderBook(exchanges);
        consolidatedOrderBook.addOrder(new Order(123456, 1,
                "MSFT", 10, true, 50.56, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 2,
                "MSFT", 6, true, 50.53,"NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 3,
                "MSFT", 10, true, 50.23, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 4,
                "MSFT", 10, true, 50.80, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 5,
                "MSFT", 10, true, 50.76, "NYSE"));

        consolidatedOrderBook.addOrder(new Order(123456, 6,
                "MSFT", 10, false, 51.56, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 7,
                "MSFT", 6, false, 51.53, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 8,
                "MSFT", 10, false, 51.23, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 9,
                "MSFT", 10, false, 51.80, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 10,
                "MSFT", 10, false, 51.76, "NYSE"));

        consolidatedOrderBook.addOrder(new Order(123456, 1,
                "MSFT", 10, true, 50.56, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 2,
                "MSFT", 6, true, 50.54, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 3,
                "MSFT", 10, true, 50.24, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 4,
                "MSFT", 10, true, 50.80, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 5,
                "MSFT", 10, true, 50.76, "BSE"));

        consolidatedOrderBook.addOrder(new Order(123456, 6,
                "MSFT", 10, false, 51.55, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 7,
                "MSFT", 6, false, 51.52, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 8,
                "MSFT", 10, false, 51.23, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 9,
                "MSFT", 10, false, 51.79, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 10,
                "MSFT", 10, false, 51.76, "BSE"));

        HashMap<Integer, OrderBook.TopNLevels> topNLevels = consolidatedOrderBook.getTopNLevels(5);
        OrderBook.TopNLevels level0 = topNLevels.get(0);
        assertNotNull(level0);
        assertTrue(50.8 == level0.getBidPrice());
        assertEquals(20, level0.getBidSize());
        System.out.println(topNLevels);
    }

    /**
     * Modify and TopN Test
     */
    @Test
    public void consolidationModifyTest()
    {
        Set<String> exchanges = new HashSet<>();
        exchanges.add("NYSE");
        exchanges.add("BSE");

        ConsolidatedOrderBook consolidatedOrderBook = new ConsolidatedOrderBook(exchanges);
        consolidatedOrderBook.addOrder(new Order(123456, 1,
                "MSFT", 10, true, 50.56, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 2,
                "MSFT", 6, true, 50.53,"NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 3,
                "MSFT", 10, true, 50.23, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 4,
                "MSFT", 10, true, 50.80, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 5,
                "MSFT", 10, true, 50.76, "NYSE"));

        consolidatedOrderBook.addOrder(new Order(123456, 6,
                "MSFT", 10, false, 51.56, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 7,
                "MSFT", 6, false, 51.53, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 8,
                "MSFT", 10, false, 51.23, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 9,
                "MSFT", 10, false, 51.80, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 10,
                "MSFT", 10, false, 51.76, "NYSE"));

        consolidatedOrderBook.addOrder(new Order(123456, 1,
                "MSFT", 10, true, 50.56, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 2,
                "MSFT", 6, true, 50.54, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 3,
                "MSFT", 10, true, 50.24, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 4,
                "MSFT", 10, true, 50.80, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 5,
                "MSFT", 10, true, 50.76, "BSE"));

        consolidatedOrderBook.addOrder(new Order(123456, 6,
                "MSFT", 10, false, 51.55, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 7,
                "MSFT", 6, false, 51.52, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 8,
                "MSFT", 10, false, 51.23, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 9,
                "MSFT", 10, false, 51.79, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 10,
                "MSFT", 10, false, 51.76, "BSE"));

        consolidatedOrderBook.modifyOrder(new Order(123456, 4,
                "MSFT", 5, true, 50.80, "BSE"));

        HashMap<Integer, OrderBook.TopNLevels> topNLevels = consolidatedOrderBook.getTopNLevels(5);
        OrderBook.TopNLevels level0 = topNLevels.get(0);
        assertNotNull(level0);
        assertTrue(50.8 == level0.getBidPrice());
        assertEquals(15, level0.getBidSize());
        System.out.println(topNLevels);
    }

    /**
     * Cancel and TopN Test
     */
    @Test
    public void consolidationCancelTest()
    {
        Set<String> exchanges = new HashSet<>();
        exchanges.add("NYSE");
        exchanges.add("BSE");

        ConsolidatedOrderBook consolidatedOrderBook = new ConsolidatedOrderBook(exchanges);
        consolidatedOrderBook.addOrder(new Order(123456, 1,
                "MSFT", 10, true, 50.56, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 2,
                "MSFT", 6, true, 50.53,"NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 3,
                "MSFT", 10, true, 50.23, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 4,
                "MSFT", 10, true, 50.80, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 5,
                "MSFT", 10, true, 50.76, "NYSE"));

        consolidatedOrderBook.addOrder(new Order(123456, 6,
                "MSFT", 10, false, 51.56, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 7,
                "MSFT", 6, false, 51.53, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 8,
                "MSFT", 10, false, 51.23, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 9,
                "MSFT", 10, false, 51.80, "NYSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 10,
                "MSFT", 10, false, 51.76, "NYSE"));

        consolidatedOrderBook.addOrder(new Order(123456, 1,
                "MSFT", 10, true, 50.56, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 2,
                "MSFT", 6, true, 50.54, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 3,
                "MSFT", 10, true, 50.24, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 4,
                "MSFT", 10, true, 50.80, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 5,
                "MSFT", 10, true, 50.76, "BSE"));

        consolidatedOrderBook.addOrder(new Order(123456, 6,
                "MSFT", 10, false, 51.55, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 7,
                "MSFT", 6, false, 51.52, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 8,
                "MSFT", 10, false, 51.23, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 9,
                "MSFT", 10, false, 51.79, "BSE"));
        consolidatedOrderBook.addOrder(new Order(123456, 10,
                "MSFT", 10, false, 51.76, "BSE"));

        consolidatedOrderBook.cancelOrder(new Order(123456, 4,
                "MSFT", 10, true, 50.80, "BSE"));

        HashMap<Integer, OrderBook.TopNLevels> topNLevels = consolidatedOrderBook.getTopNLevels(5);
        OrderBook.TopNLevels level0 = topNLevels.get(0);
        assertNotNull(level0);
        assertTrue(50.8 == level0.getBidPrice());
        assertEquals(10, level0.getBidSize());
        System.out.println(topNLevels);
    }

}
