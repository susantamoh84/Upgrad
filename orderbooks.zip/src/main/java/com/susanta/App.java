package com.susanta;

/**
 * AQR Assignment
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "AQR Assignment!" );
    }
}
