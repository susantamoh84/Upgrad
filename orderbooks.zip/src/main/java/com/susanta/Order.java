package com.susanta;

import lombok.*;

import java.util.Optional;

@Getter @Setter
@AllArgsConstructor @NoArgsConstructor @RequiredArgsConstructor
public class Order {

    @NonNull
    private long timestamp;
    @NonNull
    private long orderId;
    @NonNull
    private String symbol;
    private long quantity;
    private boolean isBuy;
    private double price;
    @NonNull
    private String exchange;

    public static final Order NULL = new Order(0, -99999, "", "");

    public boolean equals(Object order) {
        if(!(order instanceof Order))
            return false;
        long oId = ((Order)Optional.of(order).orElse(NULL)).orderId;
        return oId == this.orderId &&
                exchange.equals(((Order)Optional.of(order).orElse(NULL)).exchange);
    }

    public int hashCode(){
        return 32*(int)orderId+exchange.hashCode();
    }

}
