package com.susanta;

import lombok.*;

import java.util.Iterator;
import java.util.Optional;
import java.util.concurrent.PriorityBlockingQueue;

public class OrderBook {

    private static final double EPSILON = 1.0/1000.0;

    private PriorityBlockingQueue<Order> bidsQ = new PriorityBlockingQueue<Order>(5, OrderBook::bidComparator);
    private PriorityBlockingQueue<Order> offersQ = new PriorityBlockingQueue<Order>(5, OrderBook::askComparator);


    public boolean addOrder(Order newOrder){
        PriorityBlockingQueue<Order> orderQ = newOrder.isBuy() ? bidsQ : offersQ;
        PriorityBlockingQueue<Order> oppositeQ = newOrder.isBuy() ? offersQ : bidsQ;


        if (newOrder.getPrice()!=Double.MIN_VALUE) {
            //=====LIMIT ORDER=====
            if (oppositeQ.isEmpty() || !isLimitOrderExecutable(newOrder, oppositeQ.peek())) {
                orderQ.add(newOrder);
            }
            else {
                matchOrder(newOrder, oppositeQ);
            }
            return true;
        }
        else {
            //=====Market order=====
            if (!oppositeQ.isEmpty()) return matchOrder(newOrder, oppositeQ);
        }
        return false;
    }

    private boolean isLimitOrderExecutable(Order order, Order oppositeOrder){
        if (order.isBuy()) return order.getPrice() >= oppositeOrder.getPrice();
        else return order.getPrice() <= oppositeOrder.getPrice();
    }

    private boolean matchOrder(Order order, PriorityBlockingQueue<Order> oppositeQ){
        Order oppositeOrder = oppositeQ.peek();

        if(!Optional.ofNullable(oppositeOrder).isPresent())
            return false;

        if (order.getQuantity() < oppositeOrder.getQuantity()) {
            oppositeOrder.setQuantity(oppositeOrder.getQuantity() - order.getQuantity());
        }
        else if (order.getQuantity() > oppositeOrder.getQuantity()) {
            oppositeQ.poll();
            long reducedQty = order.getQuantity() - oppositeOrder.getQuantity();
            order.setQuantity(reducedQty);
            addOrder(order);
        }
        else if(order.getQuantity()==oppositeOrder.getQuantity())
            oppositeQ.poll();
        else
            return false;
        return true;
    }

    public boolean cancelOrder(Order order){
        PriorityBlockingQueue<Order> orderQ = order.isBuy()? bidsQ : offersQ;
        return orderQ.remove(order);
    }

    public boolean modifyOrder(Order order){
        PriorityBlockingQueue<Order> orderQ = order.isBuy() ? bidsQ : offersQ;
        PriorityBlockingQueue<Order> oppositeQ = order.isBuy() ? offersQ : bidsQ;

        Optional<Order> existingOrder = orderQ.stream().filter(o -> o.getOrderId()==order.getOrderId()).findFirst();
        if(existingOrder.isPresent()){
            orderQ.remove(order);
            Order o = existingOrder.get();
            o.setQuantity(order.getQuantity());
            o.setPrice(order.getPrice());
            orderQ.add(o);
            return true;
        }
        return false;
    }

    public static int bidComparator(Order o1, Order o2){
        if(Math.abs(o1.getPrice()-o2.getPrice()) < EPSILON)
            return 0;
        else if(o1.getPrice()>o2.getPrice())
            return -1;
        else return 1;
    }

    public static int askComparator(Order o1, Order o2){
        return -1*bidComparator(o1, o2);
    }


    public Iterator<Order> getBidIterator(){
        return bidsQ.iterator();
    }

    public Iterator<Order> getOfferIterator(){
        return offersQ.iterator();
    }

    @AllArgsConstructor
    @NoArgsConstructor
    @Getter @Setter @ToString
    static class TopNLevels{
      private double bidPrice;
      private long bidSize;
      private double askPrice;
      private long askSize;
    }
}
