package com.susanta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class ConsolidatedOrderBook {

    private ConcurrentHashMap<String, OrderBook> allOrderBooks = new ConcurrentHashMap<>();

    public ConsolidatedOrderBook(Set<String> exchanges) {
        exchanges.forEach(ex -> allOrderBooks.putIfAbsent(ex, new OrderBook()));
    }

    public boolean addOrder(Order order){
        return allOrderBooks.get(order.getExchange()).addOrder(order);
    }

    public boolean cancelOrder(Order order){
        return allOrderBooks.get(order.getExchange()).cancelOrder(order);
    }

    public boolean modifyOrder(Order order){
        return allOrderBooks.get(order.getExchange()).modifyOrder(order);
    }

    public HashMap<Integer, OrderBook.TopNLevels> getTopNLevels(int n){
        HashMap<Integer, OrderBook.TopNLevels> consolidatedTopN = new HashMap<>();

        List<Iterator<Order>> bidIterators = allOrderBooks.keySet().stream().
                map(k -> allOrderBooks.get(k).getBidIterator()).
                collect(Collectors.toList());
        List<Iterator<Order>> offerIterators = allOrderBooks.keySet().stream().
                map(k -> allOrderBooks.get(k).getOfferIterator()).
                collect(Collectors.toList());
        findTopN(consolidatedTopN, bidIterators, true, n);
        findTopN(consolidatedTopN, offerIterators, false, n);

        return consolidatedTopN;
    }

    private void findTopN(HashMap<Integer, OrderBook.TopNLevels> consolidatedTopN,
                          List<Iterator<Order>> iterators, boolean buy, int n) {
        PriorityQueue<Order> orderQueue = new PriorityQueue<>(buy?OrderBook::bidComparator:OrderBook::askComparator);
        HashMap<Order, Integer> orderIterIndex = new HashMap<>();

        pushOrders(orderQueue, iterators, orderIterIndex);
        int level = n;
        while(n>0 && !orderQueue.isEmpty()){

            Order order = orderQueue.poll();

            consolidatedTopN.putIfAbsent(level-n, new OrderBook.TopNLevels());
            updateLevelVars(consolidatedTopN.get(level-n), order.getPrice(), order.getQuantity(), buy);
            int index = orderIterIndex.get(order);
            if(iterators.get(index).hasNext()) {
                Order it = iterators.get(index).next();
                orderQueue.add(it);
                orderIterIndex.put(it, index);
            }
            orderIterIndex.remove(order);

            if(orderQueue.isEmpty())
                pushOrders(orderQueue, iterators, orderIterIndex);

            if(orderQueue.peek() != null && orderQueue.peek().getPrice()!=order.getPrice())
                n--;
        }
    }

    private void pushOrders(PriorityQueue<Order> orderPriorityQueue, List<Iterator<Order>> iterators,
                            HashMap<Order, Integer> orderIterIndex) {
        for(int i=0;i<iterators.size();i++) {
            Iterator<Order> it = iterators.get(i);
            if(it.hasNext()) {
                Order o = it.next();
                orderPriorityQueue.add(o);
                orderIterIndex.put(o, i);
            }
        }
    }

    private void updateLevelVars(OrderBook.TopNLevels topNLevels, double price,
                                 long quantity, boolean buy){
        if(buy) {
            topNLevels.setBidPrice(price);
            topNLevels.setBidSize(topNLevels.getBidSize()+quantity);
        }else{
            topNLevels.setAskPrice(price);
            topNLevels.setAskSize(topNLevels.getAskSize()+quantity);
        }
    }
}
